<?php
	

session_start();

?>
<html>
	<body>
	<?php echo $_SESSION["name1"]."<br>"; ?>
	<?php echo $_SESSION["from1"]."<br>"; ?>
	<?php echo $_SESSION["to1"]."<br>"; ?>
	<?php echo $_SESSION["day1"]."<br>"; ?>
	<?php echo $_SESSION["month1"]."<br>"; ?>
	<?php echo $_SESSION["planetype1"]."<br>"; ?>
	<?php echo $_SESSION["num1"]."<br>"; ?>
	<?php echo $_SESSION["departure1"]."<br>"; ?>
	<?php echo $_SESSION["noseat1"]."<br>"; ?>
	<?php echo $_SESSION["plane1"]."<br>"; ?>
	
	</body>
	</html>
	
	
	
		
		
		