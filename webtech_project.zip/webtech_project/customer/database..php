<?php
$username ="root";
$password ="";
$server ='localhost';
$db = 'customer';

$con= mysqli_connect($server, $username, $password, $db) or die('Database Connection error');

?>