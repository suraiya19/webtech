<!DOCTYPE html>
<html>
<head>
<title>About coffee house</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Inconsolata">
<style>
body, html {
  height: 100%;
  font-family: "Inconsolata", sans-serif;
}


}


</style>
</head>
<body>
	<a style="color:blue;font-size:200%;margin-left: 50px" href="Home.php">back</a>
	
	
<!-- Header with image -->


<!-- Add a background color and large text to the whole page -->


<!-- About Container -->
<div class="w3-container" id="about">
  <div class="w3-content" style="max-width:700px">
    <h1>ABOUT THE CAFE</h1>
    <p>The name of our cafe is <strong>Coffee house</strong>.The Cafe was founded in Dhaka by Mr. Abrar </p>
    <p>In addition to our full espresso and brew bar menu, we serve fresh made-to-order coffee
    <div class="w3-panel w3-leftbar w3-light-grey">
      <p><i>"Use products from nature for what it's worth - but never too early, nor too late." Fresh is the new sweet.</i></p>
      <p>Chef, Coffeeist and Owner: Liam Brown</p>
    </div>
    <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQlxsp9s5J2UVy1fKyI_swF8ZSJRK8fypeFRA&usqp=CAU" style="width:100%;max-width:1000px" class="w3-margin-top">
    <p><strong>Opening hours:</strong> everyday from 6am to 5pm.</p>
    <p><strong>Address:</strong> 15 Adr street, 5015, NY</p>
    
  </div>
</div>


