<?php
$username = "root";
$password = "";
$server = 'localhost';
$db = 'customer';

// $con = mysqli_connect($servername,$username,$password,$db);
$conn = mysqli_connect($server, $username, $password, $db) or die('Database Connection error');

if (isset($_POST['submit']))
{

    //echo $category;
    $firstName = $_POST['firstName'];
    $lastName = $_POST['lastName'];
    $number = $_POST['number'];
    $email = $_POST['email'];
    $dob = $_POST['dob'];
    $username = $_POST['username'];
    $pass = $_POST['Pass'];
    $confirmPassword = $_POST['confirmPassword'];

    $errors = array();

    if (empty($firstName))
    {
        $errors["firstName1"] = "name can't be  empty";
    }
    if (strlen(trim($firstName)) == 0)
    {
        $errors["firstName2"] = "Only  white space dont allowed";
    }

    else
    {
        $firstName = testInput($_POST["firstName"]);
        // check if name only contains letters and whitespace
        if (!preg_match("/^[a-zA-Z ]*$/", $firstName))
        {
            $errors["firstName3"] = "Only letters and white space allowed";
        }
    }

    if (empty($lastName))
    {
        $errors["lastName1"] = "name can't be  empty";
    }
    if (strlen(trim($lastName)) == 0)
    {
        $errors["lastName2"] = "Only  white space dont allowed";
    }

    else
    {
        $lastName = testInput($_POST["lastName"]);
        // check if name only contains letters and whitespace
        if (!preg_match("/^[a-zA-Z ]*$/", $lastName))
        {
            $errors["lastName3"] = "Only letters and white space allowed";
        }
    }

    if (empty($number))
    {
        $errors["number1"] = "number can't be  empty";
    }
    if (strlen(trim($number)) == 0)
    {
        $errors["number2"] = "Only  white space don't allowed";
    }
    if (strlen(trim($number)) != 11)
    {
        $errors["number3"] = "Only 11 digit number valid";
    }

    if (empty($email))
    {
        $errors["email1"] = "email can't be  empty";
    }
    if (strlen(trim($email)) == 0)
    {
        $errors["email2"] = "Only  white space dont allowed";
    }

    else
    {
        $email = testInput($_POST["email"]);
        // check if name only contains letters and whitespace
        if (!filter_var($email, FILTER_VALIDATE_EMAIL))
        {
            $errors["email3"] = "Invalid email format";
        }
    }

    if (empty($dob))
    {
        $errors["dob1"] = "name can't be  empty";
    }
    if (strlen(trim($dob)) == 0)
    {
        $errors["dob2"] = "Only  white space dont allowed";
    }

    if (empty($username))
    {
        $errors["username1"] = "user name can't be  empty";
    }
    if (strlen(trim($username)) == 0)
    {
        $errors["username2"] = "Only  white space dont allowed";
    }

    else
    {
        $username = testInput($_POST["username"]);
        // check if name only contains letters and whitespace
        if (!preg_match("/^[a-zA-Z ]*$/", $username))
        {
            $errors["username3"] = "Only letters and white space allowed";
        }
    }

    if (empty($pass))
    {
        $errors["pass1"] = "password can't be  empty";
    }
    if ((strlen($pass) < 2))
    {
        $errors["pass2"] = "password atleast 2 charecter long";
    }

    if (empty($confirmPassword))
    {
        $errors["confirmPassword1"] = "confirm password can't be  empty";
    }
    if ($pass != $confirmPassword)
    {
        $errors["confirmPassword2"] = "password doesn't match";
    }

    if (count($errors) == 0)
    {
        $sql = "INSERT INTO customer_registration (FirstName, LastName, Email, UserName, Password, ConfirmPassword, Dob, Phone) VALUES ('$firstName','$lastName','$email','$username','$pass','$confirmPassword','$dob','$number')";

        $run = mysqli_query($conn, $sql);
        print ($run);
        if ($run)
        {
            echo "<center><h1>Registration Successfull,Thanks!.</h1></center>";
        }
        else
        {
            echo ' Not Successfull';
            echo "Error: " . mysqli_error($conn);
        }

        mysqli_close($conn);
    }

}

function testInput($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

?>



<!DOCTYPE html>
<html>
   <head>
      <title>Resistration Page</title>
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>  
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>  
      <script>
        function valid(){

          var firstName=form.firstName.value.trim();
          var lastName=document.form.lastName.value.trim();
          var number=document.form.number.value.trim();
          var email=document.form.email.value.trim();
          var dob=document.form.dob.value.trim();
          var username=document.form.username.value.trim();
          var pass=document.form.Pass.value.trim();
          var confirmPassword=document.form.confirmPassword.value.trim();
          var msg=""; 

          if(firstName=="")
          {
            document.getElementById('firstNameErr').innerHTML="First Name is required";
            
            return false; 
          }
          if(lastName==""){
            document.getElementById('lastNameErr').innerHTML="Last Name is required";
            
            return false; 
          }

          if(email==""){
          document.getElementById('emailErr').innerHTML="Email required";

          //alert("Please fill in the field");
          return false; 
        }
        if(email!=""){
        if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(email))
          {
          
          }
            else{
              document.getElementById('emailErr2').innerHTML="Invalid email";
            return false;}
        }
        if(dob=="")
          {
            document.getElementById('dobErr').innerHTML="DOB is required";
            
            return false; 
          }

          if(number==""){
          document.getElementById('numberErr').innerHTML="Mobile number required";

          //alert("Please fill in the field");
          return false; 
        }
        if(number!=""){
        if(isNaN(mobile)){
          document.getElementById('numberErr2').innerHTML="Input valid Mobile";
          return false;
          }
        }
        
        if(number.length!=11){
            document.getElementById('numberErr3').innerHTML="Input 11 digit Mobile";
            return false;
          
        }

        if(username==""){
              document.getElementById('usernameErr').innerHTML="username required";
              return false; 
       }

        if(pass==""){
            document.getElementById('passErr').innerHTML="Password required";
            return false; 
          }
        if(confirmPassword==""){
            document.getElementById('confirmPasswordErr').innerHTML="Confirm password required";
            return false; 
          }

         
         


          else{return true;}


        }

        function success(){
          var firstName=form.firstName.value.trim();
          var lastName=document.form.lastName.value.trim();
          var number=document.form.number.value.trim();
          var email=document.form.email.value.trim();
          var dob=document.form.dob.value.trim();
          var username=document.form.username.value.trim();
          var pass=document.form.Pass.value.trim();
          var confirmPassword=document.form.confirmPassword.value.trim();

          if(firstName!=""){
          document.getElementById('firstNameErr').innerHTML=""; 
          }
        if(lastName!=""){
          document.getElementById('lastNameErr').innerHTML="";  
        }
        if(email!=""){
          document.getElementById('emailErr').innerHTML=""; 
        }
        
        if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(email)!=1)
          {
            
            document.getElementById('emailErr2').innerHTML="";
          }

          if(dob!=""){
          document.getElementById('dobErr').innerHTML=""; 
        }

        if(number!=""){
          document.getElementById('numberErr').innerHTML="";  
          
          
        if(isNaN(number)!=1){
          document.getElementById('numberErr2').innerHTML="";}
          if(number.length=11){
            document.getElementById('numberErr3').innerHTML="";
          
          }
          
          }
          
          
        if(username!=""){
              document.getElementById('usernameErr').innerHTML="";

              //alert("Please fill in the field");
            }
         if(pass!=""){
          document.getElementById('passErr').innerHTML="";

          //alert("Please fill in the field");
        }
        if(confirmPassword!=""){
          document.getElementById('confirmPasswordErr').innerHTML="";

          //alert("Please fill in the field");
        }










      }

          function validemail() 
          {
            if(form.email.value==""){
            document.getElementById('emailErr').innerHTML="Email required";

            }
            if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(form.email.value))
            {
            }
              // alert("You have entered an invalid email address!");
              else{document.getElementById('emailErr2').innerHTML="Invalid email";}
          }



      </script>



   </head>
   <body>
      <a style="color:blue;font-size:200%;margin-left: 50px" href="login.php">back</a>
      <br />  
      <div class="container">
         <div class="row col-md-6-md-offset-3">
            <div class="panel panel-primary">
               <div class="panel panel-heading text-center">
                  <h1>Customer Registration Form</h1>
               </div>
               <div class="panel panel-body">
                  <form action="" method="post" id= "form" name="form">
                     <div class="form-group">
                        <label for="firstName">First Name</label>
                        <input type="text" onkeypress="success()" value="<?php if(isset($_POST["firstName"])) echo $_POST["firstName"];?>" name="firstName" class="form-control" id="firstName">
                        <br><span style="color:red" id="firstNameErr"></span><br>
                        <p style="color:red;">
                           <?php if(isset($errors["firstName1"]))
                              {
                                echo $errors["firstName1"]."<br>";
                              }
                              if(isset($errors["firstName2"]))
                              {
                                echo $errors["firstName2"]."<br>";
                              }
                              if(isset($errors["firstName3"]))
                              {
                                echo $errors["firstName3"]."<br>";
                              }
                              ?>
                        </p>
                     </div>
                     <div class="form-group">
                        <label for="lastName">Last Name
                        </label>
                        <input type="text" onkeypress="success()" value="<?php if(isset($_POST["lastName"])) echo $_POST["lastName"];?>" name="lastName" class="form-control" id="lastName">
                        <br><span style="color:red" id="lastNameErr"></span><br>
                        <p style="color:red;">
                           <?php if(isset($errors["lastName1"]))
                              {
                                echo $errors["lastName1"]."<br>";
                              }
                              if(isset($errors["lastName2"]))
                              {
                                echo $errors["lastName2"]."<br>";
                              }
                              if(isset($errors["lastName3"]))
                              {
                                echo $errors["lastName3"]."<br>";
                              }
                              ?>
                        </p>
                     </div>
                     <div class="form-group">
                        <label for="email">Email
                        </label>
                        <input type="text" onkeypress="success()" onkeyup="validemail()" value="<?php if(isset($_POST["email"])) echo $_POST["email"];?>" name="email" class="form-control" id="email">
                        <br><span style="color:red" id="emailErr"></span><br>
                        <span style="color:red" id="emailErr2"></span><br>
                        <p style="color:red;">
                           <?php if(isset($errors["email1"]))
                              {
                                echo $errors["email1"]."<br>";
                              }
                              if(isset($errors["email2"]))
                              {
                                echo $errors["email2"]."<br>";
                              }
                              if(isset($errors["email3"]))
                              {
                                echo $errors["email3"]."<br>";
                              }
                              ?>
                        </p>
                     </div>
                     <div class="form-group">
                        <label for="Dob">Date of Birth
                        </label>
                        <input type="date" name="dob" onclick="success()" onkeyup="valid()" value="<?php if(isset($_POST["dob"])) echo $_POST["dob"];?>" class="form-control" id="dob">
                        <br><span style="color:red" id="dobErr"></span><br>
                        <p style="color:red;">
                           <?php if(isset($errors["dob1"]))
                              {
                                echo $errors["dob1"]."<br>";
                              }
                              if(isset($errors["dob2"]))
                              {
                                echo $errors["dob2"]."<br>";
                              }
                              
                              ?>
                        </p>
                     </div>
                     <div class="form-group">
                        <label for="number">Phone Number
                        </label>
                        <input type="text" onkeypress="success()"   name="number" value="<?php if(isset($_POST["number"])) echo $_POST["number"];?>" class="form-control" id="number">
                        <br><span style="color:red" id="numberErr"></span><br>
                        <span style="color:red" id="numberErr2"></span><br>
                        <span style="color:red" id="numberErr3"></span><br>
                        <p style="color:red;">
                           <?php if(isset($errors["number1"]))
                              {
                                echo $errors["number1"]."<br>";
                              }
                              if(isset($errors["numbe2"]))
                              {
                                echo $errors["number2"]."<br>";
                              }
                              if(isset($errors["number3"]))
                              {
                                echo $errors["number3"]."<br>";
                              }
                              ?>
                        </p>
                     </div>
                     <div class="form-group">
                        <label for="username">User Name
                        </label>
                        <input type="text" onkeypress="success()" name="username" class="form-control" id="username">
                        <br><span style="color:red" id="usernameErr"></span><br>
                        <p style="color:red;">
                           <?php if(isset($errors["username1"]))
                              {
                                echo $errors["username1"]."<br>";
                              }
                              if(isset($errors["username2"]))
                              {
                                echo $errors["username2"]."<br>";
                              }
                              if(isset($errors["username3"]))
                              {
                                echo $errors["username3"]."<br>";
                              }
                              ?>
                        </p>
                     </div>
                     <div class="form-group">
                        <label for="Pass">Password
                        </label>
                        <input type="password" onkeypress="success()" name="Pass" class="form-control" id="Pass">
                        <br><span style="color:red" id="passwordErr"></span><br>
                        <p style="color:red;">
                           <?php if(isset($errors["pass1"]))
                              {
                                echo $errors["pass1"]."<br>";
                              }
                              if(isset($errors["pass2"]))
                              {
                                echo $errors["pass2"]."<br>";
                              }
                              if(isset($errors["pass3"]))
                              {
                                echo $errors["pass3"]."<br>";
                              }
                              ?>
                        </p>
                     </div>
                     <div class="form-group">
                        <label for="confirmPassword">Confirm Password
                        </label>
                        <input type="password" onkeypress="success()" name="confirmPassword" class="form-control" id="confirmPassword">
                        <br><span style="color:red" id="confirmPasswordErr"></span><br>
                        <p style="color:red;">
                           <?php if(isset($errors["confirmPassword1"]))
                              {
                                echo $errors["confirmPassword1"]."<br>";
                              }
                              if(isset($errors["confirmPassword2"]))
                              {
                                echo $errors["confirmPassword2"]."<br>";
                              }
                              if(isset($errors["confirmPassword3"]))
                              {
                                echo $errors["confirmPassword3"]."<br>";
                              }
                              ?>
                        </p>
                     </div>
               </div>
               <input type="submit" value="submit" onclick="return valid()" name="submit" class="btn btn-primary" >
               </form>
            </div>
            <div class="panel panel-footer text-right">
               <small>&copy; coffee house
               </small>
            </div>
         </div>
      </div>
      </div>
   </body>
</html>

