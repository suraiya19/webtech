<!DOCTYPE html>
<html>
 
<head>
   <title>Menu Page</title>
  
<style>
  



table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
  margin-top: 22px;
  padding-top: 22px;
  margin-left: : 222px;
  padding-left: 222px;
  text-align: center;
  background-color:#d9b3ff


}

h2{
  margin-left: 322px;
  margin-top: 202px;
}
td,th {
  border: 1px solid #000000;
  
  padding: 22px;
  background-color: #d9b3ff
  margin-top: -22px;
  margin-left: 2px;
  text-align: center;
}

tr {
  background-color: #d9b3ff;
  text-align: center;
}
  .active, .dot:hover {
  background-color: #D0D0D0;
  margin-top: -22px;
  margin-left: 22px;
  text-align: center;
}
  
</style>
</head><meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Inconsolata">
<body>
  <a style="color:blue;font-size:200%;margin-left: 50px" href="Home.php">back</a>
 
  



<div i

<!-- Contact/Area Container -->
<div class="w3-container" id="where" style="padding-bottom:32px;">
  <div class="w3-content" style="max-width:700px">
    <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQlxsp9s5J2UVy1fKyI_swF8ZSJRK8fypeFRA&usqp=CAU"  style="width:100% ">
<h1>Our Menu</h1>
<table>
 
  <tr>
    <th>Name</th>
    <th>Size</th>
    <th>Price</th>
    
 
  </tr>
  
  <tr>
    <td>ESPRESSO</td>
    <td>medium</td>
    <td>120tk</td>
    
  </tr>
  <tr>
    <td>AMERICANO</td>
    <td>medium</td>
    <td>100tk</td>
    
  </tr>
  <tr>
    <td>MOCHA</td><br>
    <td>medium</td>
    <td>100tk</td>
    
  </tr>
  <tr>
    <td>ICE COFFEE</td>
    <td>medium</td>
    <td>100tk</td>
    
  </tr>
  <tr>
    <td>CAFE LATTE</td>
    <td>medium</td>
    <td>100tk</td>
    
  </tr>
  <tr>
    <td>latte</td>
    <td>medium</td>
    <td>100tk</td>
   
  </tr>
</table>
</div></div></div>





</body>
</html>









