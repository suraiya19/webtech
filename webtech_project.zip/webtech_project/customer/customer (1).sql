-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 17, 2021 at 12:04 PM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 8.0.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `customer`
--

-- --------------------------------------------------------

--
-- Table structure for table `customer_registration`
--

CREATE TABLE `customer_registration` (
  `id` int(50) NOT NULL,
  `FirstName` varchar(50) NOT NULL,
  `LastName` varchar(50) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `UserName` varchar(50) NOT NULL,
  `Password` varchar(50) NOT NULL,
  `ConfirmPassword` varchar(50) NOT NULL,
  `Dob` varchar(50) NOT NULL,
  `Phone` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customer_registration`
--

INSERT INTO `customer_registration` (`id`, `FirstName`, `LastName`, `Email`, `UserName`, `Password`, `ConfirmPassword`, `Dob`, `Phone`) VALUES
(1, 'h', 'h', 'a@gmail.com', 'g', 'g', 'g', '30/08/2422', 333),
(2, 'a', 'f', 'suraiyarahman19797@gmail.com', 'd', 'd', 'd', '2021-08-04', 3),
(3, 'q', 'q', 'suraiyarahman19797@gmail.com', 'suraiya', '1', '1', '2021-08-24', 1045),
(4, 'q', 'q', 'suraiyarahman19797@gmail.com', 'suraiya', '1', '1', '2021-08-24', 1045),
(5, 'q', 'q', 'suraiyarahman19797@gmail.com', 'suraiya', '1', '1', '2021-08-24', 1045),
(6, 'a', 'q', 'suraiyarahman19797@gmail.com', 'r', '1', '1', '', 1045),
(7, 'a', 'q', 'suraiyarahman19797@gmail.com', 'r', '1', '1', '', 1045),
(8, 'q', 'q', 'suraiyarahman19797@gmail.com', 'r', '1', '1', '2021-08-02', 1045),
(9, 'a', 'a', 'suraiyarahman19797@gmail.com', 'a', 'a', 'a', '2021-08-13', 1045),
(10, '', '', '', 'r', 'a', '', '', 0),
(11, '', '', '', 'root', '', '', '', 0),
(12, '', '', '', '', '', '', '', 0),
(13, '', '', '', '', '', '', '', 0),
(14, '', '', '', '', '', '', '', 0),
(15, '', '', '', '', '', '', '', 0),
(16, '', '', '', '', '', '', '', 0),
(17, '', '', '', '', '', '', '', 0),
(18, '', '', '', '', '', '', '', 0),
(19, '', '', '', '', '', '', '', 0),
(20, '', '', '', '', '', '', '', 0),
(21, '', '', '', '', '', '', '', 0),
(22, '', '', '', '', '', '', '', 0),
(23, '', '', '', '', '', '', '', 0),
(24, '', '', '', '', '', '', '', 0),
(25, '', '', '', '', '', '', '', 0),
(26, 'a', 'a', 'suraiyarahman19797@gmail.com', 'tdtrtyty', 'aa', 'aa', '2021-08-18', 2147483647);

-- --------------------------------------------------------

--
-- Table structure for table `order`
--

CREATE TABLE `order` (
  `id` int(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `size` varchar(50) NOT NULL,
  `price` int(50) NOT NULL,
  `quantity` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `order`
--

INSERT INTO `order` (`id`, `username`, `size`, `price`, `quantity`) VALUES
(1, 'ESPRESSO', 'medium', 120, 1),
(3, 'AMERICANO', 'medium', 120, 1);

-- --------------------------------------------------------

--
-- Table structure for table `order_table`
--

CREATE TABLE `order_table` (
  `itemid` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `itemname` varchar(50) NOT NULL,
  `size` varchar(50) NOT NULL,
  `price` int(11) NOT NULL,
  `quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `order_table`
--

INSERT INTO `order_table` (`itemid`, `username`, `itemname`, `size`, `price`, `quantity`) VALUES
(1, '0', '0', '0', 120, 1),
(2, '0', '0', '0', 120, 1),
(3, '0', '0', '0', 120, 1),
(4, 'd', 'expresso', '0', 120, 1),
(5, 'd', 'expresso', '', 0, 0),
(6, 'd', 'expresso', 'medium', 120, 1),
(7, 'd', 'expresso', 'medium', 120, 1),
(8, 'd', 'expresso', 'medium', 120, 4),
(9, 'd', 'a a', 'medium', 120, 1),
(10, 'd', 'a a', 'medium', 120, 1),
(11, '', '', '', 0, 0),
(12, 'd', 'expresso', 'medium', 120, 1),
(13, 'd', 'expresso', 'medium', 120, 1),
(14, 'd', 'a a', 'medium', 120, 1),
(15, 'd', 'a a', 'medium', 120, 1),
(16, 'd', 'a a', 'medium', 120, 1),
(17, 'd', 'a a', 'medium', 120, 1),
(18, 'd', 'a a', 'medium', 120, 1),
(19, 'd', 'a a', 'medium', 120, 1),
(20, 'd', 'e', '2021-08-18', 0, 0),
(21, 'd', 'e', '2021-08-18', 0, 0),
(22, '', '', '', 0, 0),
(23, '', '', '', 0, 0),
(24, '', '', '', 0, 0),
(25, '', '', '', 0, 0),
(26, '', '', '', 0, 0),
(27, '', '', '', 0, 0),
(28, '', '', '', 0, 0),
(29, '', '', '', 0, 0),
(30, '', '', '', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `researve_table`
--

CREATE TABLE `researve_table` (
  `researveid` int(50) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `People` int(50) NOT NULL,
  `Date_time` varchar(50) NOT NULL,
  `Message` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `researve_table`
--

INSERT INTO `researve_table` (`researveid`, `Name`, `People`, `Date_time`, `Message`) VALUES
(1, '', 0, '', ''),
(2, '', 0, '', ''),
(3, '', 0, '', ''),
(4, '', 0, '', ''),
(5, '', 0, '', ''),
(6, '', 0, '', ''),
(7, '', 0, '', ''),
(8, '', 0, '', ''),
(9, '', 0, '', ''),
(10, '', 0, '', ''),
(11, '', 0, '', ''),
(12, '', 0, '', ''),
(13, '', 0, '', ''),
(14, 'a a', 2, '', 'window side table please'),
(15, 'a a', 2, '', 'window side table please'),
(16, 'a a', 2, '', 'window side table please'),
(17, 'a a', 2, '', 'window side table please'),
(18, 'a a', 2, '', 'window side table please'),
(19, 'a a', 2, '', 'window side table please'),
(20, 'a a', 2, '', 'window side table please'),
(21, '', 0, '', 'window side table please'),
(22, '', 0, '', ''),
(23, '', 0, '', ''),
(24, '', 0, '', ''),
(25, '', 0, '', ''),
(26, '', 0, '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customer_registration`
--
ALTER TABLE `customer_registration`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order`
--
ALTER TABLE `order`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_table`
--
ALTER TABLE `order_table`
  ADD PRIMARY KEY (`itemid`);

--
-- Indexes for table `researve_table`
--
ALTER TABLE `researve_table`
  ADD PRIMARY KEY (`researveid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customer_registration`
--
ALTER TABLE `customer_registration`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `order`
--
ALTER TABLE `order`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `order_table`
--
ALTER TABLE `order_table`
  MODIFY `itemid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `researve_table`
--
ALTER TABLE `researve_table`
  MODIFY `researveid` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
