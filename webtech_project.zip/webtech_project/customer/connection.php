<?php

$username ="root";
$password ="";
$server ='localhost';
$db = 'customer';


// $con = mysqli_connect($servername,$username,$password,$db);

$conn= mysqli_connect($server, $username, $password, $db) or die('Database Connection error');
$sql = "select * from customer_registration";

$result = mysqli_query($conn, $sql)or die(mysqli_error($conn));

$data=array();

while($row = mysqli_fetch_assoc($result)) {
	$data[]=$row;
		}

foreach($data as $v){
	echo $v['E-mail'];
}


?>
jjj