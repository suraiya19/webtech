

<?php 

session_start();

$username="A";
$password="1";

if (isset($_POST['uname'])) {
  if ($_POST['uname']==$username && $_POST['pass']==$password) {
    $_SESSION['uname'] = $username;
    header("location:order.php");
  }
  else{
    $msg="username or password invalid";
    //echo "<script>alert('uname or pass incorrect!')</script>";
  }

             setcookie("uname","s",time()+60*60);

}

 ?>







<!DOCTYPE html>
<html>
<head>
  <title>login Page</title>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>  
           <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />  
           <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>  
</head>
<body>
  <a style="color:black;font-size:200%;margin-left: 50px" href="logout.php">Log Out</a>
<a style="color:blue;font-size:200%;margin-left: 50px" href="Customer_registration.php">Not yet Registered?</a>
<br>


  
           <br />  
   <div class="container">
    <div class="row col-md-6-md-offset-3">
      <div class="panel panel-primary">
        <div class="panel panel-heading text-center">
          <h1>Login</h1>
        </div>
        <div class="panel panel-body">
<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post">
  <table align="center">
    
    
    <?php if(isset($msg)){?>
       <div> <tr>
          <td colspan="2" align="center" valign="top"><?php echo $msg;?></td>
        </tr>
        </div>
      <?php } ?>
    <div><tr>
      <td>username</td>
      <td><input type="text" name="uname"></td>
    </tr></div>
    <div><tr>
      <td>password</td>
      <td><input type="password" name="pass"></td>
    </tr></div>
    <div>
    <tr>
      <td align="right" colspan="2"><input type="submit" name="login" value="login"></td>
    </tr>
    </div>

  </table>
  
</form>
</div></div></div></div>
</body>
</html>