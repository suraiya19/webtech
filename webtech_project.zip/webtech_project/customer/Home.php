<!DOCTYPE html>
<html>
<head>
<title>Coffee House</title>
</head>
<body style="background: url(https://www.teahub.io/photos/full/9-94397_1080p-coffee-wallpaper-hd.jpg); background-size: 100% 300%;background-repeat: no-repeat;">
	<a style="color:white;font-size:200%;margin-left: 50px"href="Home.php">Home</a>
	<a style="color:white;font-size:200%;margin-left: 50px" href="login.php">login</a>
	<a style="color:white;font-size:200%;margin-left: 50px" href="researv.php">reservation</a>
	<a style="color:white;font-size:200%;margin-left: 50px" href="Menu.php">Menu</a>
	<a style="color:white;font-size:200%;margin-left: 50px"href="About.php">about us</a>
	
	
	
<br>

<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>

<h1 style="text-align:center;color:white;font-size:400%">Welcome to our Coffee House</h1>


</body>
</html>
