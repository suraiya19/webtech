
<?php
$username ="root";
$password ="";
$server ='localhost';
$db = 'customer';


// $con = mysqli_connect($servername,$username,$password,$db);

$conn= mysqli_connect($server, $username, $password, $db) or die('Database Connection error');

if(isset($_POST['submit']))
{



    //echo $category;
    
    $Name=$_POST['Name'];
    $People=$_POST['People'];
     $Date_time=$_POST['Date_time'];
      $Message=$_POST['Message'];
       
    
    

    $sql = "INSERT INTO researve_table (Name,People,Date_time,Message) VALUES ('$Name','$People','$Date_time','$Message')";

    $run = mysqli_query($conn,$sql);
   
    if($run){
      echo"<center><h1>Thanks! for Researvation</h1></center>";
      print($run);
    }
    else
    {
      echo' Not Successfull';
      echo "Error: " . mysqli_error($conn);
    }

    mysqli_close($conn);

  
}


?>
<!DOCTYPE html>
<html reuire>
 <title>Researvation</title>
<head>
  
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>  
           <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />  
           <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>  
</head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Inconsolata">
<body>

  <a style="color:blue;font-size:200%;margin-left: 50px" href="Home.php">back</a>




    <div i
     


<div class="w3-container" id="where" style="padding-bottom:32px;">
  <div class="w3-content" style="max-width:700px">
    <h1 >Researvation</h1>
    
    <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQlxsp9s5J2UVy1fKyI_swF8ZSJRK8fypeFRA&usqp=CAU"  style="width:100%">
    
    <p>To <strong>Reserve</strong> a table just send us a message:</p>
    <form action="" method="post" name="form">
            
            <div class="form-group">
              <label for="Name">Name
              </label>
              <input type="text" name="Name" class="form-control" id="Name">
              
            </div>


            <div class="form-group">
              <label for="People">How many people 
              </label>
              <input type="text" name="People" class="form-control" id="People">
              
            </div>


             <div class="form-group">
              <label for="Date_time">Date & Time 
              </label>
              <input type="datetime-local" name="Date_time" class="form-control" id="Date_time">
            </div>


             <div class="form-group">
              <label for="Message">Special Requirment 
              </label>
              <input type="text" name="Message" class="form-control" id="Message">
              
            </div>
            


             



            
              <input type="submit" value="Send Message"  name="submit" class="btn btn-primary" >
              
            </div>
            
          </form>
  </div>
</div>

<!-- End page content -->
</div>

<!-- Footer -->
<div class="panel panel-footer text-right">
          <small>&copy; coffee house
          </small>
        </div>



</body>
</html>



