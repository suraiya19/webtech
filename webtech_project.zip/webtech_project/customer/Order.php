<!<!DOCTYPE html>
<html>
 
<head>
   <title>order  Page</title>
  
<style>
  



table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
  margin-top: 22px;
  padding-top: 22px;
  margin-left: : 22px;
  text-align: center;


}

td,th,tr {
  border: 1px solid #000000;
  
  padding: 222px;
  background-color: #D0D0D0
  margin-top: -22px;
  margin-left: 22px;
  text-align: center;
}

tr {
  background-color: #D0D0D0;
  text-align: center;
}
  .active, .dot:hover {
  background-color: #D0D0D0;
  margin-top: -22px;
  margin-left: 22px;
  text-align: center;
}
  
</style>
</head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Inconsolata">
<body>
  



<div i

<!-- Contact/Area Container -->
<div class="w3-container" id="where" style="padding-bottom:32px;">
  <div class="w3-content" style="max-width:700px">
      <div class="panel panel-primary">
        <div class="panel panel-heading text-center">
          <h2>Our Menu</h2>

<table>
  <div>
  <tr>
    <th>Name</th>
    <th>Size</th>
    <th>Price</th>
    
 
  </tr>
  </div>
  <tr>
    <td>ESPRESSO</td>
    <td>medium</td>
    <td>120tk</td>
    
  </tr>
  <tr>
    <td>AMERICANO</td>
    <td>medium</td>
    <td>100tk</td>
    
  </tr>
  <tr>
    <td>MOCHA</td><br>
    <td>medium</td>
    <td>100tk</td>
    
  </tr>
  <tr>
    <td>ICE COFFEE</td>
    <td>medium</td>
    <td>100tk</td>
    
  </tr>
  <tr>
    <td>CAFE LATTE</td>
    <td>medium</td>
    <td>100tk</td>
    
  </tr>
  <tr>
    <td>latte</td>
    <td>medium</td>
    <td>100tk</td>
   
  </tr>
</table>
</div>
</div>
</div>
</div>
</div><br>



</body>
</html>









<?php
$username ="root";
$password ="";
$server ='localhost';
$db = 'customer';


// $con = mysqli_connect($servername,$username,$password,$db);

$conn= mysqli_connect($server, $username, $password, $db) or die('Database Connection error');

if(isset($_POST['submit']))
{



    //echo $category;
    
    $username=$_POST['username'];
    $itemname=$_POST['itemname'];
     $size=$_POST['size'];
      $price=$_POST['price'];
       $quantity=$_POST['quantity'];
        $username=$_POST['username'];
    
    

    $sql = "INSERT INTO order_table (UserName,itemname,size,price,quantity) VALUES ('$username','$itemname','$size','$price','$quantity')";

    $run = mysqli_query($conn,$sql);
    print($run);
    if($run){
      echo"<center><h1>Thanks! for order</h1></center>";
    }
    else
    {
      echo' Not Successfull';
      echo "Error: " . mysqli_error($conn);
    }

    mysqli_close($conn);

  
}


?>
<!DOCTYPE html>
<html>
<head>
  
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>  
           <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />  
           <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>  
</head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Inconsolata">
<body>
   <a style="color:blue;font-size:200%;margin-left: 50px" href="login.php">back</a>
           <br />  
  <div i

<!-- Contact/Area Container -->
<div class="w3-container" id="where" style="padding-bottom:32px;">
  <div class="w3-content" style="max-width:700px">
      <div class="panel panel-primary">
        <div class="panel panel-heading text-center">
          <h1>Order Form</h1>
        </div>
        <div class="panel panel-body">
          <form action="" method="post" name="form">
            
            <div class="form-group">
              <label for="username">User Name
              </label>
              <input type="text" name="username" class="form-control" id="username">
              
            </div>


            <div class="form-group">
              <label for="itemname">Name of Item 
              </label>
              <input type="text" name="itemname" class="form-control" id="itemname">
              
            </div>


             <div class="form-group">
              <label for="size">Size of item 
              </label>
              <input type="text" name="size" class="form-control" id="size">
              
            </div>


             <div class="form-group">
              <label for="price">price of item 
              </label>
              <input type="text" name="price" class="form-control" id="price">
              
            </div>
            


             <div class="form-group">
              <label for="quantity">quantity of item 
              </label>
              <input type="text" name="quantity" class="form-control" id="quantity">
              
            </div>



            
              
              
            </div>
            <input type="submit" value="order"  name="submit" class="btn btn-primary" >
          </form>
        </div>
        <div class="panel panel-footer text-right">
          <small>&copy; coffee house
          </small>
        </div>
        
      </div>
      
    </div>
    
  </div>
</div>

</body>
</html>